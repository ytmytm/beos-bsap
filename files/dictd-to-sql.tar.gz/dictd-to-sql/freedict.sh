#!/bin/sh

ID=10
for NAME in freedict*.index; do
    ID=`expr $ID + 1`
    echo $NAME
    ./convert-to-sql.sh $NAME $ID
done
