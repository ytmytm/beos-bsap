#!/bin/sh

if [ $# != 2 ]; then
    echo "usage: $0 index-file dictionaryid"
    exit 1;
fi

NAME=$1
NUMB=$2

BASE="`basename $NAME .index`"

DICT="$BASE.dict.dz"
INDX="$BASE.index"
DATA="$BASE.sq2"

zgrep -q utf8 "$DICT"
UTF8=$?

if [ $? != 0 ]; then
    FROM="iso-8859-2"
else
    FROM="utf8"
fi

gunzip --decompress --stdout "$DICT" | dictunformat "$INDX" | \
	 iconv -f $FROM -t utf-8 | ./convert-to-sql.pl $NUMB >"$BASE.sql"

cat TOC | grep -v "$BASE" >TOC2
echo -e "$NUMB\t\t$BASE" >>TOC2
rm -f TOC
mv TOC2 TOC
