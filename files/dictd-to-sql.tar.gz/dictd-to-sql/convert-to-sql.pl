#!/usr/bin/perl

$word = "";
$desc = "";
$record = 0;
$dictionary = $ARGV[0];
$dictionary += 0;

$output = "-- CREATE TABLE words (id INTEGER, dictionary INTEGER, key TEXT, desc TEXT, PRIMARY KEY(id,dictionary,key));\n";

LINE:
while (<STDIN>) {

    chomp($_);

    if (/^$/) {
	next LINE;
    }

    if ((length($word)==0)&&(/^([^\s][^_]*)$/)) {
	$word = $1;
    } elsif (/^(\s+)(.*)$/) {
        $desc = $desc . $2 . "\\n";
    }

    if (/^_____$/) {
	if (($word eq "00-database-short")||($word eq "00databaseshort")) {
	    chomp($desc);
	    $short = $desc;
	} elsif (($word eq "00-database-info")||($word eq "00databaseinfo")) {
	    chomp($desc);
	    $info = $desc;
	} elsif ((length($word)>0) && (length($desc)>2)) {
	    $word =~ s/\'/\'\'/g;
	    $desc =~ s/\'/\'\'/g;
	    if ($desc =~ /^.*\\n$/) {
		chop($desc); chop($desc);
	    }
#	    print "INSERT INTO words (id,dictionary,key,desc) VALUES ($record,$dictionary,'$word','$desc');\n";
	    $output .= "INSERT INTO words (id,dictionary,key,desc) VALUES ($record,$dictionary,'$word','$desc');\n";
	    $record++;
	}
	$desc = "";
	$word = "";
	next LINE;
    }
}

$short =~ s/\'/\'\'/g;
if ($short =~ /^.*\\n$/) {
    chop($short); chop($short);
}
$info =~ s/\'/\'\'/g;
if ($info =~ /^.*\\n$/) {
    chop($info); chop($info);
}

$output = "-- CREATE TABLE dictionaries (id INTEGER, name TEXT, desc TEXT, PRIMARY KEY(id));\nINSERT INTO dictionaries (id,name,desc) VALUES ($dictionary,'$short','$info');\n" . $output;

print $output;
